from airflow import DAG
from airflow.providers.docker.operators.docker import DockerOperator
from datetime import datetime
from docker.types import Mount

with DAG(
    dag_id="crawl-campsite",
    start_date=datetime(2025, 4, 30),
    schedule="0 0 * * 5",
    catchup=False,
) as dag:
    run_crawler = DockerOperator(
        task_id="crawl-campsite",
        image="my-crawler-image:latest", 
        command="python3 /app/e_gcp_selenium_crawl.py",
        docker_url="unix://var/run/docker.sock",
        network_mode="bridge",
        auto_remove="success",
        mounts=[
            Mount(source="/home/Tibame/tjr101_project", target="/app", type="bind"),
        ], 
        mount_tmp_dir=False,
    )

    run_crawler
